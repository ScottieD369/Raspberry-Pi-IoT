<!DOCTYPE html><html><head><title>
Relay Control
</title><link rel="shortcut icon" href="RaspberryPi.ico"/>
<link rel="stylesheet" href="mystyle.css"><meta http-equiv="refresh" content="12" />
<style>
@font-face{font-family:thisFont;src:url(Hamberger-Bold.ttf);font-weight:bold;position}
</style></head><body><button class="homebtn" title="Go HOME" onclick="parent.location='index.html'">
HOME
</button><br><font face="thisFont" size="10" color="yellow"><center>
Relay Control
</font><br><br><br><font size="50px" color="yellow">
----------------------------------------------------------------
</font>
<iframe name="RelayButtons" scrolling="no" class="twentyseven" src="RelayButtons.php" title="Buttons" width="800" height="160" frameborder="0"></iframe>
<iframe name="timer" scrolling="no" class="eighteen" src="timerload.php" title="Timer" width="375" height="250" frameBorder="0"/>
</iframe></center>
</body></html>