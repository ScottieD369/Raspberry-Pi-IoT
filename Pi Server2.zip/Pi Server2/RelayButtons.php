<!DOCTYPE html><html><head><?php
exec("gpio -g mode 5 out"); exec("gpio -g mode 6 out"); // GPIO BCM
if(isset($_POST['b1'])){
 $read = exec('gpio -g read 5'); $op = fopen('rl1.txt','w+');
 if($read == 1){fwrite($op,"Off");}else{fwrite($op,"On");} fclose($op);
}
if(isset($_POST['b2'])){
 $read = exec('gpio -g read 6'); $op = fopen('rl2.txt','w+');
 if($read == 1){fwrite($op,"Off");}else{fwrite($op,"On");} fclose($op);
}
$rl1 = fopen('rl1.txt','r'); $line1 = fgets($rl1, 20);
if($line1 == "On"){$bt1 = "On"; $btt1 = "Turn Off"; $clr1 = "green"; exec("gpio -g write 5 1");}
else if($line1 == "Off"){$bt1 = "Off"; $btt1 = "Turn On"; $clr1 = "red"; exec("gpio -g write 5 0");} fclose($rl1);
$rl2 = fopen('rl2.txt','r'); $line2 = fgets($rl2, 20);
if($line2 == "On"){$bt2 = "On"; $btt2 = "Turn Off"; $clr2 = "green"; exec("gpio -g write 6 1");}
else if($line2 == "Off"){$bt2 = "Off"; $btt2 = "Turn On"; $clr2 = "red"; exec("gpio -g write 6 0");} fclose($rl2);
$tm = fopen('timer.txt','r'); $line5 = fgets($tm, 20);
if($line5 == 1){$dis1 = 1;}else{$dis1 = 0;}
if($line5 == 2){$dis2 = 1;}else{$dis2 = 0;}
fclose($tm);
?><title>
Relay Buttons
</title><style>
@font-face{font-family:thisFont;src:url(Pixim.otf);font-weight:bold;}
</style>
<link rel="shortcut icon" href="RaspberryPi.ico"/><link rel="stylesheet" href="mystyle.css"></head>
<body><center><form method="post"><table><tbody><tr><td><font size="5" face="thisFont" color="yellow">
CH 1
</font></td><td><font size="5" face="thisFont" color="yellow">
CH 2
</font></td></tr><br><tr><td>
<script>var audio = new Audio("/LaserShot1.mp3");</script>
<button name="b1" onclick="audio.play()" title="<?php echo $btt1 ?>" style="background-color:<?php echo $clr1 ?>" <?php if ($dis1 == '1'){ ?> disabled <?php } ?> ><?php echo $bt1 ?></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>
<button name="b2" onclick="audio.play()" title="<?php echo $btt2 ?>" style="background-color:<?php echo $clr2 ?>" <?php if ($dis2 == '1'){ ?> disabled <?php } ?> ><?php echo $bt2 ?></button>
</td></tr></tbody></table></form></center></body></html>