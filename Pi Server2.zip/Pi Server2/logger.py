#!/usr/bin/env python3
import os
import time
import Adafruit_DHT
DHT_SENSOR = Adafruit_DHT.DHT22
DHT_PIN = 23
while True:
 f = open('log.txt', 'w+')
 temperature,humidity = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)
 if temperature is not None:
  f.write('{:.1f}\r\n'.format(temperature))
 else:
  print("Failed to retrieve data from temperature sensor")
 f2 = open('log2.txt', 'w+')
 if humidity is not None:
  f2.write('{:.1f}\r\n'.format(humidity))
 else:
  print("Failed to retrieve data from humidity sensor")
 time.sleep(2)
