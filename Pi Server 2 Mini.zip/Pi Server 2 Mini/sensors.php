<html><head><?php
$f = fopen("/sys/class/thermal/thermal_zone0/temp","r");
$temp = fgets($f);
$cpuin = (round($temp/1000) * 9/5) + 32;
if($cpuin > 120){
 $color4 = "#ff0000";
}else if($cpuin < 40){
 $color4 = "#0000ff";
}
fclose($f);
shell_exec('sudo python logger.py');
$tempin = file_get_contents('./log.txt');
if($tempin >= 80){
 $color5 = "#ff0000";
}else if($tempin < 40){
 $color5 = "#0000ff";
}
$humidin = file_get_contents('./log2.txt');
if($humidin >= 80){
 $color6 = "#ff0000";
}else if($humidin < 30){
 $color6 = "#0000ff";
}
?>
<title>
Sensors
</title><link rel="shortcut icon" href="RaspberryPi.ico"/><link rel="stylesheet" href="mystyle.css"><meta http-equiv="refresh" content="5" />
<style>
@font-face{font-family:thisFont;src:url(Hamberger-Bold.ttf);font-weight:bold;}
</style></head><body><button class="homebtn" title="Go HOME" onclick="parent.location='index.html'">
HOME
</button><br><font face="thisFont" size="100" color="yellow"><center>
Sensors
</font><br><br><br><font size="50px" color="yellow">
----------------------------------------------------------------
</font>
<form method="post">
<h1 class="thirteen">
CPU Temp:
</h1><input class="twentyone" size="5" type="text" id="cpuin" name="cpuin" readonly value="<?php echo $cpuin ?>&#176;F" style='color:<?=$color4?>'/>
</form></body></html>