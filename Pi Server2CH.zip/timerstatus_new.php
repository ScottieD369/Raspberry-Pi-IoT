<!DOCTYPE html><html><head><?php

$fn = fopen("timer.txt","r");
$line1 = fgets($fn, 20);
$line2 = fgets($fn, 40);
$line3 = fgets($fn, 60);

$now = date("h:i:A");
$starttime = strtotime($line2);
$endtime = strtotime($line3);
echo date("h:i:A", $starttime);
echo date("h:i:A", $endtime);


  if($line1 == 1){
   exec("gpio -g write 5 0");
   $fp = fopen('rl1.txt','w+');
   fwrite($fp,"On");
   fclose($fp);
  }else if($line1 == 2){
   exec("gpio -g write 6 0");
   $fp = fopen('rl2.txt','w+');
   fwrite($fp,"On");
   fclose($fp);
  }else if($line1 == 3){
   exec("gpio -g write 13 0");
   $fp = fopen('rl3.txt','w+');
   fwrite($fp,"On");
   fclose($fp);
  }else if($line1 == 4){
   exec("gpio -g write 26 0");
   $fp = fopen('rl4.txt','w+');
   fwrite($fp,"On");
   fclose($fp);
  }

  if($line1 == 1){
   exec("gpio -g write 5 1");
   $fp = fopen('rl1.txt','r');
   fwrite($fp,"Off");
   fclose($fp);
  }else if($line1 == 2){
   exec("gpio -g write 6 1");
   $fp = fopen('rl2.txt','w+');
   fwrite($fp,"Off");
   fclose($fp);
  }else if($line1 == 3){
   exec("gpio -g write 13 1");
   $fp = fopen('rl3.txt','w+');
   fwrite($fp,"Off");
   fclose($fp);
  }else if($line1 == 4){
   exec("gpio -g write 26 1");
   $fp = fopen('rl4.txt','w+');
   fwrite($fp,"Off");
   fclose($fp);
  }

if(isset($_POST['removeTimer'])){
 $fp = fopen('timer.txt','w+');
 fwrite($fp,"");
 fclose($fp);
 echo "<script>window.open('timerload.php','timer');</script>";
}
?><title>
Sensors
</title><link rel="shortcut icon" href="RaspberryPi.ico"/>
<link rel="stylesheet" href="mystyle.css">
<meta http-equiv="refresh" content="5" />
</head><body>
<div style="color:yellow;font-size:12px;">
Channel: 
<input title="Timer Relay Channel" type="text" size="1" value="<?php echo $line1 ?>"/>&nbsp;
Start:
<input title="Start Time" type="text" size="4" value="<?php echo $line2 ?>"/>&nbsp;
End:
<input title="End Time" type="text" size="4" value="<?php echo $line3 ?>"/><br>
Remaining:
<input title="Counter" type="text" size="3" value="<?php echo $counter ?>"/>&nbsp;
Status: 
<input title="Status of Relay" type="text" size="1" value="<?php echo $sts ?>"/>
<form method="post" align="right">
<input style="cursor:pointer;" type="submit" name="removeTimer" title="Remove Timer" value="Remove" />
</form><hr>
Current time: 
</div><p style="font-size:15px;"><?php echo date("h:i:s A"); ?></p></body></html>