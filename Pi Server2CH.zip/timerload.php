<!DOCTYPE html><html><head><?php
$fn = fopen("timer.txt","r");
if (filesize('timer.txt') != 0){
 echo "<script>window.open('timerstatus.php','timer');</script>";
}
?><title>
Timer
</title><link rel="shortcut icon" href="RaspberryPi.ico"/><link rel="stylesheet" href="mystyle.css"></head><body><center>
<button title="Set Timer" onclick="window.open('timerset.php','targetWindow','titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=390,height=160,top=200,left=350');return false;">
Set Timer
</button></center></body></html>
