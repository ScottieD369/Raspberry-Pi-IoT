<!DOCTYPE html><html><head><?php
$fn = fopen("timer.txt","r");
$line1 = fgets($fn, 20);
$line2 = fgets($fn, 40);
$line3 = fgets($fn, 60);

if(isset($_POST['removeTimer'])){
 $fp = fopen('timer.txt','w+');
 fwrite($fp,"");
 fclose($fp);
 echo "<script>window.open('timerload.php','timer');</script>";
}
?><title>
Sensors
</title><link rel="shortcut icon" href="RaspberryPi.ico"/>
<link rel="stylesheet" href="mystyle.css">
</head><body>
<div style="color:yellow;font-size:12px;">
Channel: 
<input title="Timer Relay Channel" type="text" size="1" value="<?php echo $line1 ?>"/>&nbsp;
Start:
<input title="Start Time" type="text" size="4" value="<?php echo $line2 ?>"/>&nbsp;
End:
<input title="End Time" type="text" size="4" value="<?php echo $line3 ?>"/><br>
Remaining:
<input title="Counter" type="text" size="3" value="<?php echo $counter ?>"/>&nbsp;
Status: 
<input title="Status of Relay" type="text" size="1" value="<?php echo $sts ?>"/>
<form method="post" align="right">
<input style="cursor:pointer;" type="submit" name="removeTimer" title="Remove Timer" value="Remove" />
</form><hr>
Current time: 
</div><p style="font-size:15px;"><?php echo date("h:i:s A"); ?></p></body></html>