<!DOCTYPE html><html><head><?php
exec("gpio -g mode 5 out"); exec("gpio -g mode 6 out"); exec("gpio -g mode 13 out"); exec("gpio -g mode 26 out"); // GPIO BCM
$fn = fopen("timer.txt","r");
$line1 = fgets($fn, 20);
$line2 = fgets($fn, 40);
$line3 = fgets($fn, 60);
$d1 = strtotime($line2);
$d2 = strtotime($line3);
$now = date("h:i A");
$startTime = date("h:i A", $d1);
$endTime = date("h:i A", $d2);
if($now < $startTime && $endTime){
 $counter = $startTime - $now;
 if($now > $startTime){
  if($now < $endTime){
   $sts = "On";
   if($line1 == 1){exec("gpio -g write 5 0"); $op = fopen('rl1.txt','w+');fwrite($op,"On");fclose($op);} 
   else if($line1 == 2){exec("gpio -g write 6 0"); $op = fopen('rl2.txt','w+');fwrite($op,"On");fclose($op);}
   else if($line1 == 3){exec("gpio -g write 13 0"); $op = fopen('rl3.txt','w+');fwrite($op,"On");fclose($op);}
   else if($line1 == 4){exec("gpio -g write 26 0"); $op = fopen('rl4.txt','w+');fwrite($op,"On");fclose($op);} 
  }
 }
}
if($startTime < $now && $endTime){
 $counter = $endTime - $now;
 if($now >  $endTime){
  if($now < $startTime){
   $sts = "Off";
   if($line1 == 1){exec("gpio -g write 5 1"); $op = fopen('rl1.txt','w+');fwrite($op,"Off");fclose($op);}
   else if($line1 == 2){exec("gpio -g write 6 1"); $op = fopen('rl2.txt','w+');fwrite($op,"Off");fclose($op);}
   else if($line1 == 3){exec("gpio -g write 13 1"); $op = fopen('rl3.txt','w+');fwrite($op,"Off");fclose($op);}
   else if($line1 == 4){exec("gpio -g write 26 1"); $op = fopen('rl4.txt','w+');fwrite($op,"Off");fclose($op);}
  }
 }
}
fclose($fn);
if(isset($_POST['removeTimer'])){
 $fp = fopen('timer.txt','w+');
 fwrite($fp,"");
 fclose($fp);
 echo "<script>window.open('timerload.php','timer');</script>";
}
?><title>
Sensors
</title><link rel="shortcut icon" href="RaspberryPi.ico"/>
<link rel="stylesheet" href="mystyle.css">
</head><body>
<div style="color:yellow;font-size:12px;">
Channel: 
<input title="Timer Relay Channel" type="text" size="1" value="<?php echo $line1 ?>"/>&nbsp;
Start:
<input title="Start Time" type="text" size="4" value="<?php echo $startTime ?>"/>&nbsp;
End:
<input title="End Time" type="text" size="4" value="<?php echo $endTime ?>"/><br>
Remaining:
<input title="Remaining Time" type="text" size="4" value="<?php echo $counter ?>"/>&nbsp;
Status: 
<input title="Status of Relay" type="text" size="1" value="<?php echo $sts ?>"/>
<form method="post" align="right">
<input style="cursor:pointer;" type="submit" name="removeTimer" title="Remove Timer" value="Remove" />
</form><hr>
Current time: 
</div><p style="font-size:15px;"><?php echo $now ?></p></body></html>