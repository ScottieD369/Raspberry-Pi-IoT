<html><head><?php
shell_exec("gpio -g mode 22 in");   // GPIO BCM
shell_exec("gpio -g mode 22 up"); 
shell_exec("gpio -g mode 24 in");
shell_exec("gpio -g mode 24 up");
shell_exec("gpio -g mode 27 in");
shell_exec("gpio -g mode 27 up");
$ti1 = shell_exec('gpio -g read 22');
$ti3 = shell_exec('gpio -g read 24');
$ti4 = shell_exec('gpio -g read 27');
$email = file_get_contents('./data.txt');
$subject = "Alert from Raspberry Pi!";
$headers = "From: " . $email ."\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
$headers .= "X-Mailer: PHP/" . phpversion() ."\r\n";
$headers .= "X-Priority: 1" . "\r\n";
if($ti1==1){
 $doorin = "Open!";
 $color1 = "#ff0000";
 mail($email,$subject,"Door is Open!",$headers);
}else{
 $doorin = "Closed";
}
if($ti4==1){
 $windowin = "Open!";
 $color2 = "#ff0000";
 mail($email,$subject,"Window is Open!",$headers);
}else{
 $windowin = "Closed";
}
if($ti3==1){
 $movementin = "Action!";
 $color3 = "#ff0000";
 mail($email,$subject,"Movement Detected!",$headers);
}else{
 $movementin = "None";
}
$f = fopen("/sys/class/thermal/thermal_zone0/temp","r");
$temp = fgets($f);
$cpuin = (round($temp/1000) * 9/5) + 32;
if($cpuin > 105){
 $color4 = "#ff0000";
 mail($email,$subject,"CPU Temp Running Hot!",$headers);
}
fclose($f);
shell_exec('sudo python logger.py');
$tempin1 = file_get_contents('./log.txt');
$tempin = $tempin1 + 2;
if($tempin > 85){
 $color5 = "#ff0000";
 mail($email,$subject,"OutDoor Temperature is getting Hot!",$headers);
}
$humidin = file_get_contents('./log2.txt');
if($humidin >= 50){
 $color6 = "#ff0000";
 mail($email,$subject,"Humidity is getting wet!",$headers);
}
?>
<title>
Sensors
</title><link rel="shortcut icon" href="RaspberryPi.ico"/><link rel="stylesheet" href="mystyle.css"><meta http-equiv="refresh" content="5" />
<style>
@font-face{font-family:thisFont;src:url(Hamberger-Bold.ttf);font-weight:bold;}
</style></head><body><button class="homebtn" title="Go HOME" onclick="parent.location='index.html'">
HOME
</button><br><font face="thisFont" size="100" color="yellow"><center>
Sensors
</font><br><br><br><font size="50px" color="yellow">
----------------------------------------------------------------
</font>
<form method="post">
<h1 class="thirteen">
CPU Temp:
</h1><input class="twentyone" size="5" type="text" id="cpuin" name="cpuin" readonly value="<?php echo $cpuin ?>&#176;F" style='color:<?=$color4?>'/>
<h1 class="eight">
Temperature:
</h1><input class="twentytwo" size="5" type="text" id="tempin" name="tempin" readonly value="<?php echo $tempin ?>&#176;F" style='color:<?=$color5?>'>
<h1 class="nine">
Humidity:
</h1><input class="twentythree" size="4" type="text" id="humidin" name="humidin" readonly value="<?php echo $humidin ?>%" style='color:<?=$color6?>'>
<h1 class="ten">
Door Status:
</h1><input class="twentyfour" size="4" type="text" id="doorin" name="doorin" readonly value="<?php echo $doorin ?>" style='color:<?=$color1?>'/>
<h1 class="eleven">
Window Status:
</h1><input class="twentyfive" size="4" type="text" id="windowin" name="windowin" readonly value="<?php echo $windowin ?>" style='color:<?=$color2?>'/>
<h1 class="twelve">
Movement:
</h1><input class="twentysix" size="4" type="text" id="movemementin" name="movementin" readonly value="<?php echo $movementin ?>" style='color:<?=$color3?>'/>
</form>
<form  method="post"><h1 class="fourteen">
Email @
</h1><input type="text" name="ename" size="50" class="fifteen" title="Email sent to HERE" value="<?php echo $email ?>" readonly>
<button class="sixteen" title="Update Email Here" onclick="window.open('UpdateEmail.php','targetWindow');return false;" <?php if ($dis1 == '1'){ ?> disabled <?php } ?> >
Update
</button></form></body></html>