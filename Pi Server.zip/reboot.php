<!DOCTYPE html><html><head><title>
Reboot
</title><link rel="shortcut icon" href="RaspberryPi.ico"/>
<link rel="stylesheet" href="mystyle.css"></head><body><h2 align="center">
Do You Really Want To Reboot?
</h1><br><center><form method="post"><button type="submit" name="submit">
Yes
</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="window.opener=null; window.close(); return false;">
No
</button></center></body></html>

<?php
if(isset($_POST['submit']))
 exec ('sudo /sbin/shutdown -r now');
// echo '<script>window.close();</script>';  // This used to work prior to adding in command
?>