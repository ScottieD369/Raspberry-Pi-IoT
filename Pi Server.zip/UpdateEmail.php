<!DOCTYPE html><html><head><title>
Update Email
</title><link rel="shortcut icon" href="RaspberryPi.ico"/>
<link rel="stylesheet" href="mystyle.css">
</head><body><form method="post"><center><h1 align="center">
Enter a new Email address to be notified:
</h1><br><input class="tbnew" size="20" type="text" name="textdata">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button type="submit" name="submit" title="Update Now!">
Update
</button></center></form></body></html>

<?php            
if(isset($_POST['textdata'])){
 $data = $_POST['textdata'];
 $fp = fopen('data.txt','w+');
 fwrite($fp,$data);
 fclose($fp);
}
if(isset($_POST['submit'])){
 echo "<script>window.close();</script>";
}
?>