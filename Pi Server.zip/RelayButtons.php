<!DOCTYPE html><html><head><?php
exec("gpio -g mode 5 out"); exec("gpio -g mode 6 out"); exec("gpio -g mode 13 out"); exec("gpio -g mode 26 out"); // GPIO BCM
if(isset($_POST['b1'])){
 $read = exec('gpio -g read 5');
 $op = fopen('rl1.txt','w+');
 if($read == 1){fwrite($op,"On");}else{fwrite($op,"Off");}
 fclose($op);
}
if(isset($_POST['b2'])){
 $read = exec('gpio -g read 6');
 $op = fopen('rl2.txt','w+');
 if($read == 1){fwrite($op,"On");}else{fwrite($op,"Off");}
 fclose($op);
}
if(isset($_POST['b3'])){
 $read = exec('gpio -g read 13');
 $op = fopen('rl3.txt','w+');
 if($read == 1){fwrite($op,"On");}else{fwrite($op,"Off");}
 fclose($op);
}
if(isset($_POST['b4'])){
 $read = exec('gpio -g read 26');
 $op = fopen('rl4.txt','w+');
 if($read == 1){fwrite($op,"On");}else{fwrite($op,"Off");}
 fclose($op);
}
$rl1 = fopen('rl1.txt','r');
$line1 = fgets($rl1, 20);
if($line1 == "On"){$bt1 = "On"; $btt1 = "Turn Off"; $clr1 = "green"; exec("gpio -g write 5 0");}
else if($line1 == "Off"){$bt1 = "Off"; $btt1 = "Turn On"; $clr1 = "red"; exec("gpio -g write 5 1");}
fclose($rl1);
$rl2 = fopen('rl2.txt','r');
$line2 = fgets($rl2, 20);
if($line2 == "On"){$bt2 = "On"; $btt2 = "Turn Off"; $clr2 = "green"; exec("gpio -g write 6 0");}
else if($line2 == "Off"){$bt2 = "Off"; $btt2 = "Turn On"; $clr2 = "red"; exec("gpio -g write 6 1");}
fclose($rl2);
$rl3 = fopen('rl3.txt','r');
$line3 = fgets($rl3, 20);
if($line3 == "On"){$bt3 = "On"; $btt3 = "Turn Off"; $clr3 = "green"; exec("gpio -g write 13 0");}
else if($line3 == "Off"){$bt3 = "Off"; $btt3 = "Turn On"; $clr3 = "red"; exec("gpio -g write 13 1");}
fclose($rl3);
$rl4 = fopen('rl4.txt','r');
$line4 = fgets($rl4, 20);
if($line4 == "On"){$bt4 = "On"; $btt4 = "Turn Off"; $clr4 = "green"; exec("gpio -g write 26 0");}
else if($line4 == "Off"){$bt4 = "Off"; $btt4 = "Turn On"; $clr4 = "red"; exec("gpio -g write 26 1");}
fclose($rl4);
$tm = fopen('timer.txt','r');
$line5 = fgets($tm, 20);
if($line5 == 1){$dis1 = 1;}else{$dis1 = 0;}
if($line5 == 2){$dis2 = 1;}else{$dis2 = 0;}
if($line5 == 3){$dis3 = 1;}else{$dis3 = 0;}
if($line5 == 4){$dis4 = 1;}else{$dis4 = 0;}
fclose($tm);
?><title>
Relay Buttons
</title><style>
@font-face{font-family:thisFont;src:url(Pixim.otf);font-weight:bold;}
</style>
<link rel="shortcut icon" href="RaspberryPi.ico"/><link rel="stylesheet" href="mystyle.css"></head>
<body><center><form method="post"><table><tbody><tr><td><font size="5" face="thisFont" color="yellow">
CH 1
</font></td><td><font size="5" face="thisFont" color="yellow">
CH 2
</font></td><td><font size="5" face="thisFont" color="yellow">
CH 3
</font></td><td><font size="5" face="thisFont" color="yellow">
CH 4
</font></td></tr><br><tr><td>
<button name="b1" title="<?php echo $btt1 ?>" style="background-color:<?php echo $clr1 ?>" <?php if ($dis1 == '1'){ ?> disabled <?php } ?> ><?php echo $bt1 ?></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td><td><button name="b2" title="<?php echo $btt2 ?>" style="background-color:<?php echo $clr2 ?>" <?php if ($dis2 == '1'){ ?> disabled <?php } ?> ><?php echo $bt2 ?></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td><td><button name="b3" title="<?php echo $btt3 ?>" style="background-color:<?php echo $clr3 ?>" <?php if ($dis3 == '1'){ ?> disabled <?php } ?> ><?php echo $bt3 ?></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td><td><button name="b4" title="<?php echo $btt4 ?>" style="background-color:<?php echo $clr4 ?>" <?php if ($dis4 == '1'){ ?> disabled <?php } ?> ><?php echo $bt4 ?></button>
</td></tr></tbody></table></form></center></body></html>